import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Fill in the implementation details of the class DecisionTree using this file. Any methods or
 * secondary classes that you want are fine but we will only interact with those methods in the
 * DecisionTree framework.
 */
public class DecisionTreeImpl {
	public DecTreeNode root;
	public List<List<Integer>> trainData;
	public int maxPerLeaf;
	public int maxDepth;
	public int numAttr;
	public int depth;

	// Build a decision tree given a training set
	DecisionTreeImpl(List<List<Integer>> trainDataSet, int mPerLeaf, int mDepth) {
		this.trainData = trainDataSet;
		this.maxPerLeaf = mPerLeaf;
		this.maxDepth = mDepth;
		//added
		this.depth = 0;
		if (this.trainData.size() > 0) this.numAttr = trainDataSet.get(0).size() - 1;
		this.root = buildTree();
	}
	
	// Build a decision tree given a training set
		DecisionTreeImpl(List<List<Integer>> trainDataSet, int mPerLeaf, int mDepth, int depth) {
			this.trainData = trainDataSet;
			this.maxPerLeaf = mPerLeaf;
			this.maxDepth = mDepth;
			this.depth = depth;
			if (this.trainData.size() > 0) this.numAttr = trainDataSet.get(0).size() - 1;
			this.root = buildTree();
			
		}
	
	//Calculate Log
	private static double Log(double a, double b) {
		double result = 0;
		
		if(a == 0 || b == 0) {
			return 0;
		}
		if(a != 0) {
			result += (-a) * (Math.log(a)/Math.log(2));
		}
		if(b != 0) {
			result += (-b) * (Math.log(b)/Math.log(2));
		}
		return result;
	}
	
	
	//find the best ThreshHold for the given col
	private static double[] ThreshInfo(List<List<Integer>> data, int Col) {

		int Ben = 0;
		int Mal = 0;
		int last = data.get(0).size()-1;
		for(List<Integer> ex: data) {
			if(ex.get(last) == 1) {
				Mal++;
			}else {
				Ben++;
			}
		}
		double probB = (double)Ben/data.size();
		double probM = (double)Mal/data.size();
		double TotalEntropy = Log(probB,probM);
		
		double result[] = new double[11];
		for(int i=1;i<=9;i++) {
			List<List<Integer>> newLeftList = new ArrayList<List<Integer>>();
			List<List<Integer>> newRightList = new ArrayList<List<Integer>>();
			for(List<Integer> ex: data) {
				if(ex.get(Col) <= i) {
					newLeftList.add(ex);
				}else {
					newRightList.add(ex);
				}
			}
			
			double probL = (double)newLeftList.size()/data.size();
			double probR = (double)newRightList.size()/data.size();
			//	Calculate left Entropy
			int BenL = 0;
			int MalL = 0;
			for(List<Integer> ex: newLeftList) {
				if(ex.get(last) == 1) {
					MalL++;
				}else {
					BenL++;
				}
			}
			
			double LeftEntropy = 0;
			if(newLeftList.size() == 0) {
				LeftEntropy = Log(0,0);
			}else {
				double probBL = (double)BenL/newLeftList.size();
				double probML = (double)MalL/newLeftList.size();
				LeftEntropy = Log(probBL,probML);
			}
			
			
			//Calculate Right Entropy
			int BenR = 0;
			int MalR = 0;
			for(List<Integer> ex: newRightList) {
				if(ex.get(last) == 1) {
					MalR++;
				}else {
					BenR++;
				}
			}
			double RightEntropy = 0;
			if(newRightList.size() == 0) {
				RightEntropy = Log(0,0);
				
			}else {
				double probBR = (double)BenR/newRightList.size();
				double probMR = (double)MalR/newRightList.size();
				RightEntropy = Log(probBR,probMR);
			}
			
			
			//System.out.println(TotalEntropy + " " + ( LeftEntropy) +" " + (probR * RightEntropy));
			double Info = TotalEntropy - ((probL * LeftEntropy) + (probR * RightEntropy));
			result[i] = Info;
		}
		
		
		
		
		return result;
	}
	
	//get the max InfoGain number
	private static int getThresh(List<List<Integer>> data, int Col) {
		double[] Thresh = ThreshInfo(data,Col);
		double maxInfo = 0;
		int thresh = 0;
		for(int i= 1; i<=9;i++) {
			if(maxInfo < Thresh[i]) {
				maxInfo = Thresh[i];
				thresh = i;
			}
		}
		return thresh;
	}
	
	//get the max InfoGain
	private static double getInfo(List<List<Integer>> data, int Col) {
		double[] Thresh = ThreshInfo(data,Col);
		double maxInfo = 0;
		for(int i= 1; i<=9;i++) {
			if(maxInfo < Thresh[i]) {
				maxInfo = Thresh[i];
			}
		}
		return maxInfo;
	}
	
	private static int getAttri(List<List<Integer>> data) {
		double Attri[] = new double[10];
		for(int i=1;i<=9;i++) {
			Attri[i-1] = getInfo(data,i-1);
		}
		int index = 0;
		double max = 0;
		for(int i = 0;i<Attri.length;i++) {
			if(max < Attri[i]) {
				max = Attri[i];
				index = i;
			}
		}
		return index;
	}
	
	
	
	
	private DecTreeNode buildTree() {
		// TODO: add code here	
		int attribute = 0;
		int classlabel = 1;
		int threshhold = 0;
		if(trainData.size() == 0) {
			attribute = 0;
		}else {
			attribute = getAttri(trainData);
			threshhold = getThresh(trainData,attribute);
		}
		//System.out.println(root.attribute);
//		if(root == null) {
//			root = new DecTreeNode(classlabel,attribute,threshhold);
//		}
		//System.out.println(root.depth + "aaaaaaaaaaa");
		//System.out.println(depth);
		if (trainData.size() <= maxPerLeaf || depth == maxDepth || getInfo(trainData,attribute) == 0) {
			int benign = 0;
			int mal = 0;
			for(List<Integer> row: trainData) {
				if(row.get(row.size()-1) == 0) {
					benign++;
				}else if(row.get(row.size()-1) == 1) {
					mal++;
				}
			}
			if(benign == mal) {
				classlabel = 1;
			}else {
				classlabel = ((benign - mal) > 0)? 0:1;
			}
			
			//System.out.println("ssssss " + classlabel);
			DecTreeNode node = new DecTreeNode(classlabel, 0,0);
			node.left = null;
			node.right = null;
			return node;
			
			//checking
//			System.out.println("threshhold= " + threshhold);
//			System.out.println("attribute= " + attribute);
//			System.out.println("depth= " + depth);
//			System.out.println(leaf.classLabel);
			//return leaf;
		}

		
		
		
		ArrayList<List<Integer>> left = new ArrayList<List<Integer>>();
		ArrayList<List<Integer>> right = new ArrayList<List<Integer>>();
		for(List<Integer> row: trainData) {
			if(row.get(attribute) <= threshhold) {
				left.add(row);
			}else {
				right.add(row);
			}
		}
//		if(root == null) {
//			return new DecTreeNode(classlabel, attribute, threshhold);
//		}
		
		DecTreeNode node = new DecTreeNode(classlabel, attribute, threshhold);
		
		
		DecisionTreeImpl leftTree = new DecisionTreeImpl(left, maxPerLeaf, maxDepth,depth+1);
		
		node.left = leftTree.root;
		
//		leftTree.root.depth = node.depth+1;
		//System.out.println("sssssssssss" + leftTree.depth);
			
	
		DecisionTreeImpl RightTree = new DecisionTreeImpl(right, maxPerLeaf, maxDepth,depth+1);
		
		node.right = RightTree.root;
		
		//System.out.println("sssssssssss" + RightTree.depth);
			
			
		return node;
	}
	//helper function for Classify
	private int ClassifyHelper(List<Integer> instance, DecTreeNode node) {
		if(node.isLeaf()) {
			return node.classLabel;
		}
		if(!node.isLeaf()) {
			int attri = node.attribute;
			int thresh = node.threshold;
			if(instance.get(attri) <= thresh) {
				return ClassifyHelper(instance,node.left);
			}else {
				return ClassifyHelper(instance,node.right);
			}
		}
		return 0;
	}
	
	public int classify(List<Integer> instance) {
		// TODO: add code here
		// Note that the last element of the array is the label.
		DecTreeNode node = root;
		int result = ClassifyHelper(instance,node);
		
		return result;
	}
	
	// Print the decision tree in the specified format
	public void printTree() {
		printTreeNode("", this.root);
	}

	public static void printTreeNode(String prefixStr, DecTreeNode node) {
		String printStr = prefixStr + "X_" + node.attribute;
		System.out.print(printStr + " <= " + String.format("%d", node.threshold));
		if(node.left.isLeaf()) {
			System.out.println(" : " + String.valueOf(node.left.classLabel));
		}
		else {
			System.out.println();
			printTreeNode(prefixStr + "|\t", node.left);
		}
		System.out.print(printStr + " > " + String.format("%d", node.threshold));
		if(node.right.isLeaf()) {
			System.out.println(" : " + String.valueOf(node.right.classLabel));
		}
		else {
			System.out.println();
			printTreeNode(prefixStr + "|\t", node.right);
		}
	}
	
	public double printTest(List<List<Integer>> testDataSet) {
		int numEqual = 0;
		int numTotal = 0;
		for (int i = 0; i < testDataSet.size(); i ++)
		{
			int prediction = classify(testDataSet.get(i));
			int groundTruth = testDataSet.get(i).get(testDataSet.get(i).size() - 1);
			System.out.println(prediction);
			if (groundTruth == prediction) {
				numEqual++;
			}
			numTotal++;
		}
		double accuracy = numEqual*100.0 / (double)numTotal;
		System.out.println(String.format("%.2f", accuracy) + "%");
		return accuracy;
	}
	
//	public static void main(String[] args) {
//		List<List<Integer>> test = new ArrayList<>();
//		ArrayList<Integer> data1 = new ArrayList();
//		int[] data11 = {1,4,5,5,5,10,4,1,1,0};
//		for(int i: data11) {
//			data1.add(i);
//		}
//		
//		ArrayList<Integer> data2 = new ArrayList();
//		int[] data22 = {2,4,2,1,3,1,3,6,1,0};
//		for(int i: data22) {
//			data2.add(i);
//		}
//		
//		ArrayList<Integer> data3 = new ArrayList();
//		int[] data33 = {3,4,4,1,2,2,3,1,1,1};
//		for(int i: data33) {
//			data3.add(i);
//		}
//		
//		ArrayList<Integer> data4 = new ArrayList();
//		int[] data44 = {4,1,1,2,2,2,3,1,1,1};
//		for(int i: data44) {
//			data4.add(i);
//		}
//		
//		test.add(data1);
//		test.add(data2);
//		test.add(data3);
//		test.add(data4);
//
//		for(int i=0; i<test.size();i++) {
//			for(int j =0; j<test.get(0).size();j++) {
//				System.out.print(test.get(i).get(j) + ",");
//			}
//			System.out.println();
//		}
//		//double[] testp = PAtri(test,2);
//		//System.out.println(CalEntropy(testp));
////		System.out.println(Entropy(test));
////		System.out.println(CalInfo(test,0));
////		System.out.println(BestAttr(test));
//		double[] result = ThreshInfo(test,0);
//		for(int i = 0;i <9; i++) {
//			System.out.println("index= " + i + " " + getThresh(test,i) + " "+ getInfo(test,i));
//		}
//		System.out.println(getAttri(test));
//		System.out.println(getThresh(test,0));
//		System.out.println(getInfo(test,0));
//		DecisionTreeImpl tree = new DecisionTreeImpl(test,1,3);
//		System.out.println(tree.root.classLabel);
//		//System.out.println(tree.root.left.classLabel);
//		printTreeNode("s",tree.root);
//		//8,10,10,8,5,10,7,8,1,1
//		ArrayList<Integer> testdata = new ArrayList<>();
//		testdata.add(8);
//		testdata.add(10);
//		testdata.add(10);
//		testdata.add(8);
//		testdata.add(5);
//		testdata.add(10);
//		testdata.add(7);
//		testdata.add(8);
//		testdata.add(1);
//		testdata.add(1);
//		//System.out.println(tree.classify(testdata));
//		ArrayList<List<Integer>> testdatax = new ArrayList<List<Integer>>();
//		testdatax.add(testdata);
//		tree.printTest(testdatax);
//		
//		
//		
//	}
}
