package maze;
import java.util.ArrayList;
import java.util.PriorityQueue;

/**
 * A* algorithm search
 * 
 * You should fill the search() method of this class.
 */
public class AStarSearcher extends Searcher {

	/**
	 * Calls the parent class constructor.
	 * 
	 * @see Searcher
	 * @param maze initial maze.
	 */
	public AStarSearcher(Maze maze) {
		super(maze);
	}

	/**
	 * helper function
	 * adding Euclidean function
	 */
	private double EuDistance(Square a, Square b) {
		double x = a.X - b.X;
		double y = a.Y - b.Y;
		double xSquare = x * x;
		double ySquare = y * y;
		double result = Math.sqrt(xSquare + ySquare);
		return result;
	}
	
	/**
	 * helper function
	 * check whether or not node n is in the frontier
	 */
	public boolean isInFrontier(PriorityQueue<StateFValuePair> frontier, State s) {
		boolean isin = false;
		for(StateFValuePair p : frontier) {
			if(p.getState().equals(s)) {
				isin = true;
			}
		}
		return isin;
	}
	
	/**
	 * helper function
	 * find the same State node
	 */
	
	public StateFValuePair FindthePair(PriorityQueue<StateFValuePair> frontier, StateFValuePair a) {
		for(StateFValuePair f : frontier) {
			if(f == a) {
				return f;
			}
		}
		System.out.println("can't find the node in Frontier");
		return a;
	}
	
	/**
	 * Main a-star search algorithm.
	 * 
	 * @return true if the search finds a solution, false otherwise.
	 */
	public boolean search() {

		// FILL THIS METHOD

		// explored list is a Boolean array that indicates if a state associated with a given position in the maze has already been explored. 
		boolean[][] explored = new boolean[maze.getNoOfRows()][maze.getNoOfCols()];
		// ...

		PriorityQueue<StateFValuePair> frontier = new PriorityQueue<StateFValuePair>();
		Square goal = maze.getGoalSquare();
		

		// TODO initialize the root state and add
		// to frontier list
		// ...
		State initial = new State(maze.getPlayerSquare(),null,0,0);
		frontier.add(new StateFValuePair(initial,initial.getGValue() + EuDistance(initial.getSquare(),goal)));
		

		while (!frontier.isEmpty()) {
			// TODO return true if a solution has been found
			// TODO maintain the cost, noOfNodesExpanded (a.k.a. noOfNodesExplored),
			// maxDepthSearched, maxSizeOfFrontier during
			// the search
			// TODO update the maze if a solution found
			StateFValuePair root = frontier.poll();
			noOfNodesExpanded++;
			
			//set the maximum depth of the search
			if(root.getState().getDepth() > maxDepthSearched) {
				maxDepthSearched = root.getState().getDepth();
			}
			
			//testing
			//System.out.println(root.getState().getX() + " "+ root.getState().getY());
			
			// find the goal
			if(root.getState().isGoal(maze)) {
				
				State currentState = root.getState();
				maze.setOneSquare(maze.getPlayerSquare(),'S');
				maze.setOneSquare(maze.getGoalSquare(), 'G');
				while(currentState.getSquare() != maze.getPlayerSquare()) {
					cost++;
					currentState = currentState.getParent();
					if(currentState.getSquare() == maze.getPlayerSquare()) {
						
					}else {
						maze.setOneSquare(currentState.getSquare(), '.');
					}
				}
				return true;
			}
			
			//set explored to true!!
			explored[root.getState().getX()][root.getState().getY()] = true;
			
			
			//get the children nodes
			ArrayList<State> children = root.getState().getSuccessors(explored, maze);
			
			for(State child : children) {
				StateFValuePair node = new StateFValuePair(child,child.getGValue() + EuDistance(child.getSquare(),goal));
				if(!child.isExplored(explored) && !isInFrontier(frontier, child)) {
					frontier.add(node);
					explored[child.getX()][child.getY()] = true;
					
					if(frontier.size() > maxSizeOfFrontier) {
						maxSizeOfFrontier = frontier.size();
						}
					//continue;
				}
				else if(isInFrontier(frontier, child)) {
					StateFValuePair m = FindthePair(frontier,node);
					System.out.println("here !!!!!!!!!");
					if(child.getGValue() >= m.getState().getGValue()) {
						System.out.println("best path!!!!!!!");
						
					}else {
						noOfNodesExpanded--;
						frontier.remove(m);
						frontier.add(node);
						if(frontier.size() > maxSizeOfFrontier) {
							maxSizeOfFrontier = frontier.size();
						}
						System.out.println("A star Adding duplicate success");
						}
					}
				}
			
			// use frontier.poll() to extract the minimum stateFValuePair.
			// use frontier.add(...) to add stateFValue pairs
		}

		// return false if no solution
		return false;
	}


}
