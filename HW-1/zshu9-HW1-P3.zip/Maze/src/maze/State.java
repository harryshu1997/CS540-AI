package maze;

import java.util.ArrayList;

/**
 * A state in the search represented by the (x,y) coordinates of the square and
 * the parent. In other words a (square,parent) pair where square is a Square,
 * parent is a State.
 * 
 * You should fill the getSuccessors(...) method of this class.
 * 
 */
public class State {

	private Square square;
	private State parent;

	// Maintain the gValue (the distance from start)
	// You may not need it for the BFS but you will
	// definitely need it for AStar
	private int gValue;

	// States are nodes in the search tree, therefore each has a depth.
	private int depth;

	/**
	 * @param square
	 *            current square
	 * @param parent
	 *            parent state
	 * @param gValue
	 *            total distance from start
	 */
	public State(Square square, State parent, int gValue, int depth) {
		this.square = square;
		this.parent = parent;
		this.gValue = gValue;
		this.depth = depth;
	}

	/**
	 * @param visited
	 *            explored[i][j] is true if (i,j) is already explored
	 * @param maze
	 *            initial maze to get find the neighbors
	 * @return all the successors of the current state
	 */
	public ArrayList<State> getSuccessors(boolean[][] explored, Maze maze) {
		// FILL THIS METHOD
		int leftx = square.X;
		int lefty = square.Y-1;
		int downx = square.X+1;
		int downy = square.Y;
		int rightx = square.X;
		int righty = square.Y+1;
		int upx = square.X-1;
		int upy = square.Y;
		ArrayList<State> successors = new ArrayList<State>();
		State current;	
			if(maze.getSquareValue(leftx, lefty) != '%' && !explored[leftx][lefty]) {
				current = new State(new Square(leftx,lefty),this,this.getGValue()+1,depth+1);
				successors.add(current);
			}
			if(maze.getSquareValue(downx, downy) != '%' && !explored[downx][downy]) {
				current = new State(new Square(downx, downy),this,this.getGValue()+1,depth+1);
				successors.add(current);
			}
			if(maze.getSquareValue(rightx, righty) != '%' && !explored[rightx][righty]) {
				current = new State(new Square(rightx, righty),this,this.getGValue()+1,depth+1);
				successors.add(current);
			}
			if(maze.getSquareValue(upx, upy) != '%' && !explored[upx][upy]) {
				current = new State(new Square(upx, upy),this,this.getGValue()+1,depth+1);
				successors.add(current);
			}
		

		// TODO check all four neighbors in left, down, right, up order
		// TODO remember that each successor's depth and gValue are
		// +1 of this object.
		return successors;
	}

	//override equals method
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof State)) { 
			System.out.println("not a state!!!");
            return false; 
        } 
		
		if(((State) o).getX() == this.getX() && ((State) o).getY() == this.getY()) {
			return true;
			
		}
		
		return false;
	}
	/**
	 * @return x coordinate of the current state
	 */
	public int getX() {
		return square.X;
	}
	
	//to see if a state is explored
	public boolean isExplored(boolean explored[][]) {
		return explored[this.getX()][this.getY()];
	}

	/**
	 * @return y coordinate of the current state
	 */
	public int getY() {
		return square.Y;
	}

	/**
	 * @param maze initial maze
	 * @return true is the current state is a goal state
	 */
	public boolean isGoal(Maze maze) {
		if (square.X == maze.getGoalSquare().X
				&& square.Y == maze.getGoalSquare().Y)
			return true;

		return false;
	}

	/**
	 * @return the current state's square representation
	 */
	public Square getSquare() {
		return square;
	}

	/**
	 * @return parent of the current state
	 */
	public State getParent() {
		return parent;
	}

	/**
	 * You may not need g() value in the BFS but you will need it in A-star
	 * search.
	 * 
	 * @return g() value of the current state
	 */
	public int getGValue() {
		return gValue;
	}

	/**
	 * @return depth of the state (node)
	 */
	public int getDepth() {
		return depth;
	}
}
