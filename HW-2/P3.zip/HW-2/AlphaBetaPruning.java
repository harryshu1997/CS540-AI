public class AlphaBetaPruning {


    public AlphaBetaPruning() {
    }
    public static int depth=0;
    public static int move=0;
    public static double bestmove=0.0;
    public static int maxdepth=0;
    public static int Evaluatednode=0;
    public static int Visitednode=0;
    public static int countfactor=0;

    /**
     * This function will print out the information to the terminal,
     * as specified in the homework description.
     */
    public void printStats() {
        System.out.println("Move: "+move);
        System.out.println("Value: "+bestmove);
        System.out.println("Number of Nodes Visited: "+Visitednode);
        System.out.println("Number of Nodes Evaluated: "+Evaluatednode);
        System.out.println("Max Depth Reached: "+ maxdepth);
        System.out.println("Avg Effective Branching Factor: "+ (double)countfactor/(double)(Visitednode-Evaluatednode));
        //System.out.println("Avg Effective Branching Factor: "+);
        // TODO Add your code here
    }

    /**
     * This function will start the alpha-beta search
     * @param state This is the current game state
     * @param depth This is the specified search depth
     */
    public void run(GameState state, int depth) {
        this.depth=depth;
        int count=0;
        for (int i = 1; i < state.stones.length; i++) {
            if (!state.stones[i])
                count++;
       }
        boolean maxPlayer=true;
        if(count%2==1) maxPlayer=false;
        bestmove =alphabeta(state,0,Double.NEGATIVE_INFINITY,Double.POSITIVE_INFINITY,maxPlayer);
    }

    /**
     * This method is used to implement alpha-beta pruning for both 2 players
     * @param state This is the current game state
     * @param depth Current depth of search
     * @param alpha Current Alpha value
     * @param beta Current Beta value
     * @param maxPlayer True if player is Max Player; Otherwise, false
     * @return int This is the number indicating score of the best next move
     */
    private double alphabeta(GameState state, int depth, double alpha, double beta, boolean maxPlayer) {
        Visitednode++;
        if(this.depth==depth||state.getSuccessors().size()==0) {
            if (depth > maxdepth)//update maxdepth
                maxdepth = depth;
            Evaluatednode++;
            return state.evaluate();
        }
           else if(maxPlayer==true){
                double v=Double.NEGATIVE_INFINITY;
                double bestv=Double.NEGATIVE_INFINITY;
              //  System.out.println("个数"+state.getSuccessors().size()+" "+depth);
                for(int i=0;i<state.getSuccessors().size();i++) {
                    countfactor++;
               //   System.out.println("last move"+state.getSuccessors().get(i).getLastMove());
                    GameState child=state.getSuccessors().get(i);

                    v = Double.max(v, alphabeta(state.getSuccessors().get(i), depth + 1, alpha, beta, false));
                    if(bestv<v&&depth==0) {
                        bestv = v;
                        child=state.getSuccessors().get(i);
                        move=child.getLastMove();
                    }
                    if(v>=beta) return v;
                    alpha=Double.max(alpha,v);

                    }
                return v;
            }
            else{
            double v=Double.POSITIVE_INFINITY;
            double bestv=Double.POSITIVE_INFINITY;
              //  System.out.println("个数"+state.getSuccessors().size()+" "+depth);

                for(int i=0;i<state.getSuccessors().size();i++){
                    countfactor++;
               //   System.out.println("last move"+state.getSuccessors().get(i).getLastMove()+" "+alpha+" "+ beta);
                   //GameState child=state.getSuccessors().get(i);
                    v=Double.min(v, alphabeta(state.getSuccessors().get(i), depth + 1, alpha, beta, true));
                    GameState child=state.getSuccessors().get(i);
                    //find out the best childstate and it's lastmove is the bestmove
                    if(bestv>v&&depth==0) {
                        bestv = v;
                        child=state.getSuccessors().get(i);
                        move=child.getLastMove();
                    }
                    if(v<=alpha) return v;
                    beta=Double.min(beta,v);
                }
                return v;
            }
        }

    }

