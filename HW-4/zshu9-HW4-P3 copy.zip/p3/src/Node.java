import java.util.*;

/**
 * Class for internal organization of a Neural Network.
 * There are 5 types of nodes. Check the type attribute of the node for details.
 * Feel free to modify the provided function signatures to fit your own implementation
 */

public class Node {
    private int type = 0; //0=input,1=biasToHidden,2=hidden,3=biasToOutput,4=Output
    public ArrayList<NodeWeightPair> parents = null; //Array List that will contain the parents (including the bias node) with weights if applicable

    private double inputValue = 0.0;
    private double outputValue = 0.0;
    private double outputGradient = 0.0;
    public double delta = 0.0; //input gradient
    public double target = 0.0;

    //Create a node with a specific type
    Node(int type) {
        if (type > 4 || type < 0) {
            System.out.println("Incorrect value for node type");
            System.exit(1);

        } else {
            this.type = type;
        }

        if (type == 2 || type == 4) {
            parents = new ArrayList<>();
        }
    }

    //For an input node sets the input value which will be the value of a particular attribute
    public void setInput(double inputValue) {
        if (type == 0) {    //If input node
            this.inputValue = inputValue;
        }
    }

    /**
     * the activation function
     *
     * @param x input from input layer
     * @return the activation function value
     */
    private double act(double x) {
        if (x >= 0)
            return x;
        return 0.0;
    }
    private double act1(double x) {
        if (x <= 0)
            return 0.0;
        return 1.0;
    }
    public void softmax(double x){
        this.outputValue = this.outputValue/x;
    }
    
    /**
     * Calculate the output of a node.
     * You can get this value by using getOutput()
     */
    public void calculateOutput() {
    	double sum = 0.0;
        if (type == 2 || type == 4) {   //Not an input or bias node
            if (type == 2) {//an hidden unit
                for (int i = 0; i < this.parents.size(); i++) {
                    //System.out.print(1);
                    sum += (this.parents.get(i).node.getOutput()) * (this.parents.get(i).weight);
                }
                this.outputValue = act(sum);
                this.outputGradient = act1(sum);

            }
            if (type == 4) {//an out put unit
                for (int i = 0; i < this.parents.size(); i++) {

                        sum += (this.parents.get(i).node.getOutput())*(this.parents.get(i).weight);

                }
                this.outputValue=Math.exp(sum);
            }
        }
    }

    //Gets the output value
    public double getOutput() {

        if (type == 0) {    //Input node
            return inputValue;
        } else if (type == 1 || type == 3) {    //Bias node
            return 1.00;
        } else {
            return outputValue;
        }

    }

    //Calculate the delta value of a node.
    public void calculateDelta() {
    	 if (type == 2 || type == 4) {
             if(type==4){
                 this.delta = this.target - this.getOutput();
             }
             if(type==2){
                 this.delta = this.target * this.outputGradient;
             }
         }
    }


    //Update the weights between parents node and current node
    public void updateWeight(double learningRate) {
    	if (type == 2 || type == 4) {
            if(type==4){
                for(int i=0;i<this.parents.size();i++){
                    this.parents.get(i).weight += learningRate*(this.parents.get(i).node.getOutput())*this.delta;
                }
            }
            if(type==2){
                for (int i = 0; i < this.parents.size(); i++) {
                    this.parents.get(i).weight += learningRate*(this.parents.get(i).node.getOutput())*this.delta;
                }
            }
        }
    }
}


